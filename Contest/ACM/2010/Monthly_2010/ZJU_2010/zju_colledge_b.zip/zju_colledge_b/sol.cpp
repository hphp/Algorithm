#include<cstring>
#include<cstdlib>
#include<cstdio>
int const N=26,R=7,C=16;
int const S=300;
char image[N][R][C+5]=
{
	{
		"111111MMM1111111",
		"11111MM1MM111111",
		"1111MM111MM11111",
		"111MMMMMMMMM1111",
		"11MM1111111MM111",
		"1MMM11111111MM11",
		"1MM1111111111MM1"
	},
	{
		"1MMMMMMMMMMM1111",
		"1MM11111111MM111",
		"1MM11111111MM111",
		"1MMMMMMMMMMM1111",
		"1MM11111111MM111",
		"1MM11111111MM111",
		"1MMMMMMMMMMM1111"
	},
	{
		"11111MMMMMMMM111",
		"111MM1111111MM11",
		"11MM111111111MM1",
		"11MM111111111111",
		"11MM111111111MM1",
		"111MM1111111MM11",
		"11111MMMMMMMM111"
	},
	{
		"1MMMMMMMMMMM1111",
		"1MM111111111MM11",
		"1MM1111111111MM1",
		"1MM1111111111MM1",
		"1MM1111111111MM1",
		"1MM111111111MM11",
		"1MMMMMMMMMMM1111"
	},
	{
		"1MMMMMMMMMMMM111",
		"1MM1111111111111",
		"1MM1111111111111",
		"1MMMMMMMMMMMM111",
		"1MM1111111111111",
		"1MM1111111111111",
		"1MMMMMMMMMMMM111"
	},
	{
		"1MMMMMMMMMMMMM11",
		"1MM1111111111111",
		"1MM1111111111111",
		"1MMMMMMMMMMMMM11",
		"1MM1111111111111",
		"1MM1111111111111",
		"1MM1111111111111"
	},
	{
		"11111MMMMMMMM111",
		"111MM1111111MM11",
		"11MM111111111MM1",
		"11MM111111111111",
		"11MM111111MMMMM1",
		"111MM1111111MM11",
		"11111MMMMMMMMM11"
	},
	{
		"1MM111111111MM11",
		"1MM111111111MM11",
		"1MM111111111MM11",
		"1MMMMMMMMMMMMM11",
		"1MM111111111MM11",
		"1MM111111111MM11",
		"1MM111111111MM11"
	},
	{
		"11111MMMMMM11111",
		"1111111MM1111111",
		"1111111MM1111111",
		"1111111MM1111111",
		"1111111MM1111111",
		"1111111MM1111111",
		"11111MMMMMM11111"
	},
	{
		"1111MMMMMMMM1111",
		"1111111MM1111111",
		"1111111MM1111111",
		"1111111MM1111111",
		"111MM11MM1111111",
		"111MMM1MM1111111",
		"11111MMMM1111111"
	},
	{
		"11MM111111MMM111",
		"11MM11111MMM1111",
		"11MM111MMM111111",
		"11MMMMM111111111",
		"11MM111MMM111111",
		"11MM11111MMM1111",
		"11MM111111MMMM11"
	},
	{
		"11MM111111111111",
		"11MM111111111111",
		"11MM111111111111",
		"11MM111111111111",
		"11MM111111111111",
		"11MM111111111111",
		"11MMMMMMMMMMMM11"
	},
	{
		"1MM1111111111MM1",
		"1MMMM111111MMMM1",
		"1MM1MM1111MM1MM1",
		"1MM11MMMMM111MM1",
		"1MM1111M11111MM1",
		"1MM1111111111MM1",
		"1MM1111111111MM1"
	},
	{
		"1MMM111111111MM1",
		"1MMMM11111111MM1",
		"1MM1MM1111111MM1",
		"1MM11MM111111MM1",
		"1MM1111MM1111MM1",
		"1MM111111MMM1MM1",
		"1MM11111111MMMM1"
	},
	{
		"11111MMMMMM11111",
		"111MMM1111MMM111",
		"11MMM111111MMM11",
		"1MM1111111111MM1",
		"11MMM111111MMM11",
		"111MMM1111MMM111",
		"11111MMMMMM11111"
	},
	{
		"1MMMMMMMMMMM1111",
		"1MM111111111MM11",
		"1MM1111111111MM1",
		"1MM111111111MM11",
		"1MMMMMMMMMMM1111",
		"1MM1111111111111",
		"1MM1111111111111"
	},
	{
		"11111MMMMMM11111",
		"111MMM1111MMM111",
		"11MMM111111MMM11",
		"1MM1111111111MM1",
		"11MMM1MMMM1MMM11",
		"111MMM11MMMMM111",
		"111111MMMM1MMMM1"
	},
	{
		"1MMMMMMMMMMM1111",
		"1MM111111111MM11",
		"1MM1111111111MM1",
		"1MM111111111MM11",
		"1MMMMMMMMMMM1111",
		"1MM11111111MM111",
		"1MM111111111MMM1"
	},
	{
		"1111MMMMMMMM1111",
		"111MM1111111MM11",
		"11MMM1111111MMM1",
		"1111MMMMM1111111",
		"1MMM111MMMM11111",
		"111MMM11111MMM11",
		"11111MMMMMMM1111"
	},
	{
		"11MMMMMMMMMMMM11",
		"11MMMMMMMMMMMM11",
		"1111111MM1111111",
		"1111111MM1111111",
		"1111111MM1111111",
		"1111111MM1111111",
		"1111111MM1111111"
	},
	{
		"1MM1111111111MM1",
		"1MM1111111111MM1",
		"1MM1111111111MM1",
		"1MM1111111111MM1",
		"1MMM11111111MMM1",
		"1MMM11111111MMM1",
		"111MMMMMMMMMM111"
	},
	{
		"1MMMM111111MMMM1",
		"11MMM111111MMM11",
		"11MMM111111MMM11",
		"111MMM1111MMM111",
		"1111MMM11MMM1111",
		"11111MM11MM11111",
		"111111MMMM111111"
	},
	{
		"1MM1111111111MM1",
		"1MM1111111111MM1",
		"11MM111MM111MM11",
		"11MM111MM111MM11",
		"11MM111MM111MM11",
		"11MM1MM11MM1MM11",
		"111MMM1111MMM111"
	},
	{
		"11MMM111111MMM11",
		"111MMM1111MMM111",
		"1111MMM11MMM1111",
		"111111MMMM111111",
		"1111MMM11MMM1111",
		"111MMM1111MMM111",
		"11MMM111111MMM11"
	},
	{
		"11MMM111111MMM11",
		"111MMM1111MMM111",
		"1111MMM11MMM1111",
		"111111MMMM111111",
		"1111111MM1111111",
		"1111111MM1111111",
		"1111111MM1111111"
	},
	{
		"111MMMMMMMMMM111",
		"1111111111MM1111",
		"111111111MM11111",
		"11111111MM111111",
		"111111MM11111111",
		"11111MM111111111",
		"111MMMMMMMMMMM11"
	}
};
int cc[N][R*C][2];
int num[N];
int const ND=8;
int const D[ND][2]={
	{-1,0},{1,0},{0,-1},{0,1},
	{-1,-1},{-1,1},{1,-1},{1,1}
};
int q[R*C][2];
bool b[S][S];
char bd[S][S];
bool a[N];
int n,m;
inline bool in(int r,int c)
{
	return r>=0&&r<R&&c>=0&&c<C;
}
inline bool in1(int r,int c)
{
	return r>=0&&r<n&&c>=0&&c<m;
}
int cmp(void const *aa,void const *bb)
{
	int const *a=(int const *)aa;
	int const *b=(int const *)bb;
	return a[0]!=b[0]?a[0]-b[0]:a[1]-b[1];
}
int cmp1(void const *aa,void const *bb)
{
	int const *a=(int const *)aa;
	int const *b=(int const *)bb;
	return a[0]!=b[0]?b[0]-a[0]:b[1]-a[1];
}
int bfs(int ch)
{
	int pos,cnt;
	int x0,y0,x,y,xx,yy;
	int i,j,k;
	for(i=0;i<R;++i)
	{
		for(j=0;j<C;++j)
		{
			if(image[ch][i][j]=='M')
			{
				x0=i;
				y0=j;
				goto END;
			}
		}
	}
	END:
		;
	memset(b,false,sizeof(b));
	q[0][0]=x0;
	q[0][1]=y0;
	cc[ch][0][0]=0;
	cc[ch][0][1]=0;
	cnt=1;
	b[x0][y0]=true;
	pos=0;
	while(pos<cnt)
	{
		xx=q[pos][0];
		yy=q[pos][1];
		++pos;
		for(k=0;k<ND;++k)
		{
			x=xx+D[k][0];
			y=yy+D[k][1];
			if(in(x,y)&&image[ch][x][y]=='M'&&!b[x][y])
			{
				q[cnt][0]=x;
				q[cnt][1]=y;
				cc[ch][cnt][0]=x-x0;
				cc[ch][cnt][1]=y-y0;
				++cnt;
				b[x][y]=true;
			}
		}
	}
	return cnt;
}
void dfs(int x0,int y0)
{
	int pp[R*C][2];
	int pos,cnt;
	int x,y,xx,yy;
	int i,j,k;
	q[0][0]=x0;
	q[0][1]=y0;
	cnt=1;
	b[x0][y0]=true;
	pos=0;
	while(pos<cnt)
	{
		xx=q[pos][0];
		yy=q[pos][1];
		++pos;
		for(k=0;k<ND;++k)
		{
			x=xx+D[k][0];
			y=yy+D[k][1];
			if(in1(x,y)&&bd[x][y]=='M'&&!b[x][y])
			{
				q[cnt][0]=x;
				q[cnt][1]=y;
				++cnt;
				b[x][y]=true;
			}
		}
	}
	qsort(q,cnt,sizeof(int[2]),cmp);
	pp[0][0]=0;
	pp[0][1]=0;
	for(k=1;k<cnt;++k)
	{
		pp[k][0]=q[k][0]-q[0][0];
		pp[k][1]=q[k][1]-q[0][1];
	}
	for(i=0;i<N;++i)
	{
		if(cnt!=num[i])
			continue;
		for(j=0;j<num[i];++j)
			if(cc[i][j][0]!=pp[j][0]||cc[i][j][1]!=pp[j][1])
				break;
		if(j==num[i])
		{
			a[i]=true;
			return;
		}
	}
	qsort(q,cnt,sizeof(int[2]),cmp1);
	pp[0][0]=0;
	pp[0][1]=0;
	for(k=1;k<cnt;++k)
	{
		pp[k][0]=q[0][0]-q[k][0];
		pp[k][1]=q[0][1]-q[k][1];
	}
	for(i=0;i<N;++i)
	{
		if(cnt!=num[i])
			continue;
		for(j=0;j<num[i];++j)
			if(cc[i][j][0]!=pp[j][0]||cc[i][j][1]!=pp[j][1])
				break;
		if(j==num[i])
		{
			a[i]=true;
			return;
		}
	}
}
void initialize()
{
	int k;
	for(k=0;k<N;++k)
	{
		num[k]=bfs(k);
		qsort(cc[k],num[k],sizeof(int[2]),cmp);
	}
}
bool readin()
{
	int i,j;
	if(scanf("%d%d",&n,&m)==EOF)
		return false;
	for(i=0;i<n;++i)
	{
		getchar();
		for(j=0;j<m;++j)
		{
			bd[i][j]=getchar();
		}
	}
	return true;
}
void solve()
{
	int i,j,k;
	memset(a,false,sizeof(a));
	memset(b,false,sizeof(b));
	for(i=0;i<n;++i)
		for(j=0;j<m;++j)
			if(bd[i][j]=='M'&&!b[i][j])
				dfs(i,j);
	for(k=0;k<N;++k)
		if(a[k])
			putchar('A'+k);
	putchar('\n');
}
int main()
{
	initialize();
	while(readin())
		solve();
	return 0;
}

