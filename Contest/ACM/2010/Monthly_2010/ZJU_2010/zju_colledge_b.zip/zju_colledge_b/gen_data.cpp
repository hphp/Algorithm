#include<assert.h>
#include<cstring>
#include<cstdio>
int const A=26,R=7,C=16;
int const N=6;
int const L=200;
char line[L+10];
char dic[A][R][C];
int main()
{
	FILE *fpin=fopen("data.txt","r");
	FILE *fpout=fopen("jpeg.txt","w");
	int i=0,j=0,k,l,t;
	while(fgets(line,L,fpin))
	{
		if(line[0]=='\n')
		{
			++i;
			j=0;
			continue;
		}
		k=0;
		l=0;
		while(line[l]!='\n')
		{
			t=0;
			while(line[l]=='1'||line[l]=='M')
			{
				dic[i*N+k][j][t++]=line[l++];
			}
			while(line[l]!='1'&&line[l]!='M'&&line[l]!='\n')
				++l;
			++k;
		}
		++j;
	}
	for(i=0;i<A;++i)
	{
		for(j=0;j<R;++j)
		{
			for(k=0;k<C;++k)
			{
				fputc(dic[i][j][k],fpout);
			}
			fputc('\n',fpout);
		}
		fputc('\n',fpout);
	}
	fclose(fpin);
	fclose(fpout);
	return 0;
}

