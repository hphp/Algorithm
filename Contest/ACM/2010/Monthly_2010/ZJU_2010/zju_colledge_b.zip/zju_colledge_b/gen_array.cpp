#include<cstring>
#include<cstdio>
int main()
{
	int const L=200;
	FILE *fpin=fopen("jpeg.txt","r");
	FILE *fpout=fopen("sol.cpp","w");
	char line[L+10];
	fputc('{',fpout);
	fputc('\n',fpout);
	fputc('\t',fpout);
	fputc('{',fpout);
	fputc('\n',fpout);
	while(fgets(line,L,fpin))
	{
		if(line[0]=='\n')
		{
			fputc('\t',fpout);
			fputc('}',fpout);
			fputc(',',fpout);
			fputc('\n',fpout);
			fputc('\t',fpout);
			fputc('{',fpout);
			fputc('\n',fpout);
		}
		else
		{
			line[strlen(line)-1]='\0';
			fprintf(fpout,"\t\t\"%s\",\n",line);
		}
	}
	fputc('}',fpout);
	fclose(fpin);
	fclose(fpout);
	return 0;
}

